package com.example.src

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
